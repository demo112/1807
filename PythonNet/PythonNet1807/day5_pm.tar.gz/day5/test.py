def fun(a):
    a = "nihao"

l = 'hello world'
fun(l)
print(l)