# mymap.py


# map函数示例
def power2(x):
    return x ** 2


for x in map(power2, range(1, 10)):
    print(x)  # 1 4 9 16 .... 81











