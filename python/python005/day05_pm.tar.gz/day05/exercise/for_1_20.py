# 练习:
#   用 for语句打印 1 ~ 20 的整数,打印在一行内:
#     1 2 3 4 5 ..... 20

for i in range(1, 21):
    print(i, end=' ')
else:
    print()  # 换行

    