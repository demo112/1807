

# 打印全世界所有的文字
for code in range(0, 65536):
    ch = chr(code)
    print(ch, end='')


