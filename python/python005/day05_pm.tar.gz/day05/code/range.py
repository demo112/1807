# range.py

for x in range(4):
    print(x)  # 0, 1, 2, 3
else:
    print("可迭代对象已经不能再提供数据.for结束")

for x in range(3, 6):
    print(x)
print('----------------------------')
for x in range(1, 10, 2):
    print(x)