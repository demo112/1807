# while_continue.py


# 此示例示意在while中使用contine语句
# 略过2

x = 0
while x < 5:
    if x == 2:
        x += 1
        continue
    print(x)
    x += 1



