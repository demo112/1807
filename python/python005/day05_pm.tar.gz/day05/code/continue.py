# continue.py


# 此示例示意contine语句的用法和作用
for x in range(5):
    if x == 2:
        continue
    print(x)
