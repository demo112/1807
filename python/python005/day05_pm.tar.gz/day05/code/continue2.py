# continue2.py


# 打印10以内的奇数
for x in range(10):
    if x % 2 == 0:  # 是偶数,跳过
        continue
    print(x)



