# for.py

s = "ABCD"
for ch in s:
    print("ch--->>", ch)

