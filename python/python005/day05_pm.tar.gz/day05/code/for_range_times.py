# for_range_times.py


i = 6
for x in range(1, i):  # for x in range(1, 6)
    print('x =', x, 'i=', i)
    i -= 1

# 请问打印结果是什么?

