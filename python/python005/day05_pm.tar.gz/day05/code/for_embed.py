

# 此示例示意for语句的嵌套
for x in "ABC":
    for y in "123":
        print(x + y)

