# mymod3.py


# 此模块示意模块的隐藏属性
def f1():
    pass


def _f2():
    pass


def __f3():
    pass


name1 = "abc"
_name2 = '123'








