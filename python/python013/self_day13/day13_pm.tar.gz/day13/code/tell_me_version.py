# tell_me_version.py


import sys
print('current version is ', sys.version)


