
# mypack/games/__init__.py

__all__ = ['contra', 'supermario']



