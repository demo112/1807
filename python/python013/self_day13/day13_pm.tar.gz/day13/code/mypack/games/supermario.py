# mypack/games/supermario.py


def play():
    print("正在玩 超级玛丽....")


print("超级玛丽 模块被加载")

