# mypack/__init__.py

'''　我的自定义包 mypack

此包内有两个子包:
   games
   office
还有一个模块
   menu.py
'''


def test_mypack():
    print("这是mypack/__init__.py里的test_mypack函数")


print("mypack/__init__.py被加载")

