# sys_argv.py


import sys

print('当前用户输入的参数个数是:', len(sys.argv))
print("当前用户的参数的列表是:", sys.argv)

