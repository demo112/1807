# test_relative_import.py


# 调用mypack/games/contra.py里的gameover()
import mypack.games.contra

mypack.games.contra.gameover()