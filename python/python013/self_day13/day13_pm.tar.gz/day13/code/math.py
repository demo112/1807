# mymod.py


# 此示例示意自义模块
def myfac(n):
    print("正在计算%d的阶乘...." % n)


def mysum(n):
    print("正在计算1+2+3+....+", n, '的和....')


name1 = "audi"
name2 = 'Tesla'

