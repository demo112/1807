

import sys

print('这是第一行打印')

sys.exit()

print('这是第二行打印')