# test_mymod.py


# import 语句导入自定义模块
# import mymod  # 导入自定义模块
# mymod.myfac(5)  # 调用mymod里的函数myfac
# mymod.mysum(1000)
# print(mymod.name1)  # 获取mymod.name1属性绑定的数据


# from import 语句导入自定义模块
# from mymod import myfac as fac, mysum, name2
# fac(10)
# mysum(100)
# print(name2)

from mymod import *
myfac(1000)

