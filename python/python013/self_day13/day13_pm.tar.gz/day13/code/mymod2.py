# mymod2.py


# 此例表限定当用from mymod2 import *时只导入f1和var1
__all__ = ['f1', 'var1']

def f1():
    pass

def f2():
    pass

def f3():
    pass

var1 = 100
var2 = 200

