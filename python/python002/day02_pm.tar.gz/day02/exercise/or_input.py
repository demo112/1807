score = input("请输入学生成绩:") or '0'
score = int(score)

print("成绩是:", score)
