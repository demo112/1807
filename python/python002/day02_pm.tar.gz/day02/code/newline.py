# newline.py

# \ 折行符,可以显示进行折行
x = 1 + (2 * 3) + 4 \
+ 5 + 6 + 7


print(x)  