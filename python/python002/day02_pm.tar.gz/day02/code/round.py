
# 此示例示意round的用法 

x = 123.456789

print(round(x))
print(round(x, 2))  # 123.46
print(round(123.455, 2))   # 123.45
print(round(x, -1))  # 120.0
print(round(x, -5))  # 0.0