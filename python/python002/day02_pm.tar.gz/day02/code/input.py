# input.py


s = input("请输入一些文字: ")

print('您刚才输入的文字是:', s)


s2 = input()
print("您第二次输入的是:", s2)

r = input("请输入一个整数: ")
r = int(r)
print(r, "/ 2= ", r / 2)

