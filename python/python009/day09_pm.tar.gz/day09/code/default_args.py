# default_args.py


def info(name, age=1, address='不详'):
    print('我叫', name, '我今年',
          age, '岁,我的住址:', address)


info('魏明择', 35, '朝阳区')
info('Tarena', 15)  # <--两个参数调用
info('张飞')
# info()  # 出错




