# positional_give_args.py


# 此示例示意位置传参
def myfun(a, b, c):
    '这是一个函数传参的示例'
    print('a的值是:', a)
    print('b的值是:', b)
    print('c的值是:', c)


myfun(1, 2, 3)
myfun(4, 5, 6)
myfun(5, 6, 4)

