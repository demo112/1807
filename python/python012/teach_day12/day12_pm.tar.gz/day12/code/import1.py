# import1.py

import math  # 导入数学模块

print(math.factorial(5))
print(math.factorial(4))

print(math.cos(0))  # 1





