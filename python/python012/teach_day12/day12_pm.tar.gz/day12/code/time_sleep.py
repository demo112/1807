# time_sleep.py


print("程序开始...")

import time

time.sleep(10)

print("程序结束")