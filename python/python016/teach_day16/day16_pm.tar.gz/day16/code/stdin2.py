# stdin.py

# 此示例示意标准输入文件 sys.stdin 的用法

import sys

s = sys.stdin.read()

print(s)
