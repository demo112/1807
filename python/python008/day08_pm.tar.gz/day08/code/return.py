# return.py


# 此示例示意return 语句在函数中的作用
def say_hello():
    print("hello world!")
    print("hello tarena!")
    return [1, 2, 3]
    print("hello everyone")


v = say_hello()
print('v =', v)
# say_hello()
# say_hello()

