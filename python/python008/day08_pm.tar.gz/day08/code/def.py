# def.py


# 此示例示意用def语句来定义一个函数并调用这个函数

def say_hello():
    print("hello world!")
    print("hello tarena!")
    print("hello everyone!")
    # return None


say_hello()  # 函数调用
say_hello()
v = say_hello()
print(v)  # None
